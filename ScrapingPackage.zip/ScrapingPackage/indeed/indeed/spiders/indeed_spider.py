from scrapy import Spider
from scrapy import Request
from indeed.items import IndeedItem

class IndeedSpider(Spider):
    name = 'indeed_spider'
    allowed_domains = ['www.indeed.com']
    # All remote jobs
    # Remote Jobs by NYC-located Companies
    start_urls=['https://www.indeed.com/jobs?q=&l=remote&rbl=Remote&jlid=aaa2b906602aa8f5&fromage=7']

    def parse(self,response):
        num_items=int(response.xpath('//div[@id="searchCountPages"]/text()').extract()[0].strip().split()[3].replace(',',''))
        #num_items=50
        result_urls=[f'https://www.indeed.com/jobs?l=remote&rbl=Remote&jlid=aaa2b906602aa8f5&fromage=7&start={i}' for i in range(num_items, -10, -10)]
        print('                  ')
        print('                  ')
        print(num_items)
        print('                  ')
        print('                  ')
        
        for url in result_urls:
            yield Request(url=url, callback=self.parse_jobs_page)
    
    def parse_jobs_page(self,response):
        date=response.xpath('//span[@class="date "]/text()').extract_first()
        print(date)
        
        #if date in ['6 days ago', '7 days ago']:
        # if date=="3 days ago":
            # print('=============')
            # print(date)
            # print('=============')
            # return()
        joblinks=['https://www.indeed.com'+url for url in response.xpath('//h2[@class="title"]//@href').extract()]
        #joblinks=response.xpath('//div[@data-tn-component="organicJob"]/@data-jk').extract()
        #joblinks=[response.url+'&vjk='+ url for url in joblinks]
        
        dates=response.xpath('//span[@class="date "]/text()').extract()
        #print(dates)
        for url,date in zip(joblinks,dates):
            meta={'date':date}
            yield Request(url=url, callback=self.parse_job_page,meta=meta)
            
    def parse_job_page(self,response):
            
        jobtitle=response.xpath('//h1[@class="icl-u-xs-mb--xs icl-u-xs-mt--none jobsearch-JobInfoHeader-title"]/text()').extract()[0]
        company=response.xpath('//div[@class="icl-u-lg-mr--sm icl-u-xs-mr--xs"]//text()').extract()[0]
        desc=(''.join(response.xpath('//div[@class="jobsearch-jobDescriptionText"]//text()').extract())).strip()
        
        #date=response.xpath('//div[@class="jobsearch-JobMetadataFooter"]/div/text()').extract_first()
        
        try:
            salary=response.xpath('//span[@class="icl-u-xs-mr--xs"]/text()').extract()[0]
        except:
            salary='NA'
        
        try:
            qual=(''.join(response.xpath('//ul[@class="jobsearch-ReqAndQualSection-item--wrapper"]//text()').extract())).strip()
        except:
            qual='NA'
        
        item=IndeedItem()
        item['Date']=response.meta['date']
        item['JobTitle']=jobtitle
        item['JobLoc']='Remote'
        item['Company']=company
        item['Qualifications']=qual
        item['Salary']=salary
        item['Text']=desc
        
        
        print('='*55)
        print(item)
        print('='*55)
        yield item
        