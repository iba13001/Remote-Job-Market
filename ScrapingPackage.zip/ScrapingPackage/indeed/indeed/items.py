# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class IndeedItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    JobTitle=scrapy.Field()
    JobLoc=scrapy.Field()
    Company=scrapy.Field()
    Date=scrapy.Field()
    Qualifications=scrapy.Field()
    Text=scrapy.Field()
    Salary=scrapy.Field()